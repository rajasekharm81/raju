import React, { useState, useEffect } from "react";
import axios from "axios"; // corrected import statement
import { Image } from "cloudinary-react";
import "./Upload.css";

function Upload() {
  const [selectedImage, setSelectedImage] = useState("");
  const [uploadedImages, setUploadedImages] = useState([]);

  const uploadImage = () => {
    const formData = new FormData();
    formData.append("file", selectedImage);
    formData.append("upload_preset", "ohnmmopp");
    axios
      .post("https://api.cloudinary.com/v1_1/dhuwymwdc/image/upload", formData)
      .then((response) => {
        console.log("Image uploaded successfully. Response:", response);
        const newImages = [...uploadedImages, response.data.secure_url];
        setUploadedImages(newImages);
        localStorage.setItem("uploadedImages", JSON.stringify(newImages));
      })
      .catch((error) => {
        console.error("Error uploading the image: ", error);
      });
  };

  useEffect(() => {
    const storedImages = JSON.parse(localStorage.getItem("uploadedImages"));
    if (storedImages) {
      setUploadedImages(storedImages);
    }
  }, []);

  return (
    <div className="cont-container mt-5 m-5 col-11 col-md-6 mx-auto d-flex flex-column align-items-center">
      <div className="text-center">
        <input
          type="file"
          onChange={(event) => {
            setSelectedImage(event.target.files[0]);
          }}
        />
        <button className="btn btn-primary mt-3" onClick={uploadImage}>
          Upload
        </button>
      </div>
      <div className="col-11 col-md-4 flex-wrap mt-5">
        {uploadedImages.length > 0 && (
          <div>
            <h2 className="text-center">Uploaded Images</h2>
            <div className="d-flex flex-wrap justify-content-center">
              {uploadedImages.map((imageUrl, index) => (
                <div key={index} className="m-3">
                  <Image
                    cloudName="dhuwymwdc"
                    publicId={imageUrl}
                    width="300"
                  />
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default Upload;
